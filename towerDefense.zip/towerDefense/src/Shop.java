import javax.swing.*;

public class Shop extends JPanel {
    public Shop(JPanel game){

    }
}
