import javax.swing.*;
import java.awt.*;


public class Shop extends JPanel {
    private Game game;
    private int playerMoney = 100;
    private JLabel moneyLabel;
    private JPanel shopContentPanel;
    int basic=50;
    int melee=75;
    int sniper=100;
    int mg=150;


    public Shop(Game game) {
        this.game = game;
        setPreferredSize(new Dimension(220, 600));
        setLayout(new BorderLayout());
        setBackground(new Color(220, 220, 220));


        // Inner panel that will be placed inside the scroll pane
        shopContentPanel = new JPanel();
        shopContentPanel.setLayout(new BoxLayout(shopContentPanel, BoxLayout.Y_AXIS));
        shopContentPanel.setBackground(new Color(220, 220, 220));


        JLabel title = new JLabel("Tower Shop");
        title.setFont(new Font("Arial", Font.BOLD, 18));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        shopContentPanel.add(Box.createVerticalStrut(20));
        shopContentPanel.add(title);


        moneyLabel = new JLabel("Money: $" + playerMoney);
        moneyLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        moneyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        shopContentPanel.add(Box.createVerticalStrut(10));
        shopContentPanel.add(moneyLabel);
        shopContentPanel.add(Box.createVerticalStrut(20));


        // Add tower entries
        shopContentPanel.add(createTowerPanel("Basic Tower", basic, 5, 10, 100,
                () -> game.setSelectedTowerToPlace(new Tower("basic", 5, 10, 100, 0, 0))));
        shopContentPanel.add(createTowerPanel("Melee Tower", melee, 10, 15, 50,
                () -> game.setSelectedTowerToPlace(new Tower("melee", 10, 15, 50, 0, 0))));
        shopContentPanel.add(createTowerPanel("Sniper Tower", sniper, 50, 50, 200,
                () -> game.setSelectedTowerToPlace(new Tower("sniper", 50, 50, 200, 0, 0))));
        shopContentPanel.add(createTowerPanel("MG Tower", mg, 3, 3, 100,
                () -> game.setSelectedTowerToPlace(new Tower("mg", 3, 3, 100, 0, 0))));


        // Add scroll pane
        JScrollPane scrollPane = new JScrollPane(shopContentPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setBorder(null); // optional: clean look
        add(scrollPane, BorderLayout.CENTER);
    }


    private JPanel createTowerPanel(String name, int cost, int damage, int fireRate, int range, Runnable onBuy) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.setBackground(new Color(245, 245, 245));
        panel.setMaximumSize(new Dimension(180, 180)); // increased for image space


        // Load tower image
        try {
            ImageIcon icon = new ImageIcon("src/Images/" + name.toLowerCase().split(" ")[0] + ".png");
            Image scaledImage = icon.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
            JLabel imageLabel = new JLabel(new ImageIcon(scaledImage));
            imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(Box.createVerticalStrut(5));
            panel.add(imageLabel);
        } catch (Exception e) {
            System.out.println("Could not load image: " + name.toLowerCase().split(" ")[0] + ".png");
        }


        JLabel nameLabel = new JLabel(name);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);


        JLabel costLabel = new JLabel("Cost: $" + cost);
        JLabel damageLabel = new JLabel("Damage: " + damage);
        JLabel fireRateLabel = new JLabel("Fire Rate: " + 60/fireRate);
        JLabel rangeLabel = new JLabel("Range: " + range);


        for (JLabel label : new JLabel[]{costLabel, damageLabel, fireRateLabel, rangeLabel}) {
            label.setFont(new Font("Arial", Font.PLAIN, 12));
            label.setAlignmentX(Component.CENTER_ALIGNMENT);
        }


        JButton buyButton = new JButton("Buy");
        buyButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buyButton.addActionListener(e -> {
            if (playerMoney >= cost) {
                playerMoney -= cost;
                updateMoneyDisplay();
                onBuy.run();
            } else {
                JOptionPane.showMessageDialog(null, "Not enough money!");
            }
        });


        panel.add(nameLabel);
        panel.add(costLabel);
        panel.add(damageLabel);
        panel.add(fireRateLabel);
        panel.add(rangeLabel);
        panel.add(Box.createVerticalStrut(5));
        panel.add(buyButton);
        panel.add(Box.createVerticalStrut(5));
        shopContentPanel.add(Box.createVerticalStrut(10)); // space between tower panels


        return panel;
    }
    public void applyInflation(double inflationRate){
        refreshShop((int)(basic*inflationRate),(int)(melee*inflationRate),(int)(sniper*inflationRate),(int)(mg*inflationRate));
    }
    public void refreshShop(int basicCost, int meleeCost, int sniperCost, int MGcost) {
        shopContentPanel.removeAll();

        // Re-add title and money label
        JLabel title = new JLabel("Tower Shop");
        title.setFont(new Font("Arial", Font.BOLD, 18));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        shopContentPanel.add(Box.createVerticalStrut(20));
        shopContentPanel.add(title);

        moneyLabel = new JLabel("Money: $" + playerMoney);
        moneyLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        moneyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        shopContentPanel.add(Box.createVerticalStrut(10));
        shopContentPanel.add(moneyLabel);
        shopContentPanel.add(Box.createVerticalStrut(20));

        // Re-add tower panels (you can change values dynamically here)
        shopContentPanel.add(createTowerPanel("Basic Tower", basicCost, 5, 10, 100,
                () -> game.setSelectedTowerToPlace(new Tower("basic", 5, 10, 100, 0, 0))));
        shopContentPanel.add(createTowerPanel("Melee Tower", meleeCost, 10, 15, 50,
                () -> game.setSelectedTowerToPlace(new Tower("melee", 10, 15, 50, 0, 0))));
        shopContentPanel.add(createTowerPanel("Sniper Tower", sniperCost, 50, 50, 200,
                () -> game.setSelectedTowerToPlace(new Tower("sniper", 50, 50, 200, 0, 0))));
        shopContentPanel.add(createTowerPanel("MG Tower", MGcost, 3, 3, 100,
                () -> game.setSelectedTowerToPlace(new Tower("mg", 3, 3, 100, 0, 0))));

        shopContentPanel.revalidate();
        shopContentPanel.repaint();
    }





    public void setPlayerMoney(int money){
        this.playerMoney=money;
        updateMoneyDisplay();
    }
    public void updateMoneyDisplay() {
        moneyLabel.setText("Money: $" + playerMoney);
    }


    public void earnMoney(int amount) {
        playerMoney += amount;
        updateMoneyDisplay();
    }
}
