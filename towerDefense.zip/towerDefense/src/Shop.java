import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Shop extends JPanel {
    private Game game;
    private int playerMoney = 2000;
    private JLabel moneyLabel;


    public Shop(Game game){
        this.game = game;
        setPreferredSize(new Dimension(200,600));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(new Color(200,200,200));


        JLabel title = new JLabel("Shop");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createVerticalStrut(20));
        add(title);


        moneyLabel = new JLabel("Money: " + playerMoney);
        moneyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createVerticalStrut(10));
        add(moneyLabel);


        add(Box.createVerticalStrut(20));


        JButton buyBasicButton = new JButton("Buy Basic: 50");
        buyBasicButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buyBasicButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if(playerMoney >= 50){
                    playerMoney -= 50;
                    updateMoneyDisplay();
                    game.setSelectedTowerToPlace(new Tower("basic", 5,10,100,0,0));
                } else{
                    JOptionPane.showMessageDialog(null, "No money dun dun dun");
                }
            }
        });
        add(buyBasicButton);


        JButton buyMeleeButton = new JButton("Buy Melee: 75");
        buyMeleeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buyMeleeButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if(playerMoney >= 75){
                    playerMoney -= 75;
                    updateMoneyDisplay();
                    game.setSelectedTowerToPlace(new Tower("melee", 20,10,50,0,0));
                } else{
                    JOptionPane.showMessageDialog(null, "No money dun dun dun");
                }
            }
        });
        add(buyMeleeButton);


        JButton buySniperButton = new JButton("Buy Sniper: 100");
        buySniperButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buySniperButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if(playerMoney >= 100){
                    playerMoney -= 100;
                    updateMoneyDisplay();
                    game.setSelectedTowerToPlace(new Tower("sniper", 50,30,200,0,0));
                } else{
                    JOptionPane.showMessageDialog(null, "No money dun dun dun");
                }
            }
        });
        add(buySniperButton);


        JButton buyMachineGunButton = new JButton("Buy Machine Gun: 150");
        buyMachineGunButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buyMachineGunButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if(playerMoney >= 150){
                    playerMoney -= 150;
                    updateMoneyDisplay();
                    game.setSelectedTowerToPlace(new Tower("mg", 5,3,100,0,0));
                } else{
                    JOptionPane.showMessageDialog(null, "No money dun dun dun");
                }
            }
        });
        add(buyMachineGunButton);
    }
    public void updateMoneyDisplay(){
        moneyLabel.setText("Money: " + playerMoney);
    }
    public void earnMoney(int amount){
        playerMoney += amount;
        updateMoneyDisplay();
    }
}



