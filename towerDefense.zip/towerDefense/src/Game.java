import javax.swing.*;

public class Game extends JPanel{
    Timer timer;

    public Game(){

    }
}
