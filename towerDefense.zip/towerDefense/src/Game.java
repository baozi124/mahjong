import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;




public class Game extends JPanel implements ActionListener, MouseListener {
    Timer timer;
    ArrayList<Enemy>enemies =  new ArrayList<>();
    ArrayList<Tower>towers = new ArrayList<>();
    int currentWave = 0;
    boolean waveInProgress = false;
    int enemiesLeftToSpawn = 0;
    int enemySpawnDelay = 20; // delay between enemies in a wave
    int enemySpawnDelayTimer = 0;
    Shop shop;
    private int playerHealth = 10;  // or whatever starting value you want
    private Clip deathSound;


    int[][] checkpoints={{-50,400},{100,400},{100,100},{700,100},{700,250},{300,250},{300,450},{900,450}};
    public Game(){
        addMouseListener(this);
        this.setFocusable(true);
        timer = new Timer(16, this);
        timer.start();
        
        try {
            File soundFile = new File("src/Music/death.wav");
            if (!soundFile.exists()) {
                System.out.println("Sound file not found: " + soundFile.getAbsolutePath());
            }
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);
            deathSound = AudioSystem.getClip();
            deathSound.open(audioIn);
            System.out.println("Sound loaded");
        } catch (Exception e) {
            e.printStackTrace();
        }

        //button to start wave
        JButton startWaveButton = new JButton("Start Next Wave");
        startWaveButton.addActionListener(e -> {
            if (!waveInProgress) {
                startNextWave();
            }
        });
        this.add(startWaveButton);




    }
    private Tower selectedTowerToPlace = null;
    public void setSelectedTowerToPlace(Tower tower){
        this.selectedTowerToPlace = tower;
    }


    private void startNextWave() {
        currentWave++;
        enemiesLeftToSpawn = (int)(Math.pow(currentWave, 1.5));//difficulty
        enemySpawnDelay = Math.max(5, 40 - currentWave * 2);
        waveInProgress = true;
        enemySpawnDelayTimer = 0;
    }




    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);


        g.setColor(new Color(137, 161, 122)); //background
        g.fillRect(0, 0, getWidth(), getHeight());




        // Draw path lines
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setColor(new Color(195, 175, 144));
        g2d.setStroke(new BasicStroke(75));




        for (int i = 0; i < checkpoints.length - 1; i++) {
            int x1 = checkpoints[i][0];
            int y1 = checkpoints[i][1];
            int x2 = checkpoints[i + 1][0];
            int y2 = checkpoints[i + 1][1];
            g2d.drawLine(x1, y1, x2, y2);
        }
        g2d.dispose();




        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Wave: " + currentWave, 20, 30);

        // Health bar
        int maxHealth = 10; // Set your max health value here
        int barWidth = 200;
        int barHeight = 20;
        int barX = 20;
        int barY = 530;
        int healthBarWidth = (int)((playerHealth / (double)maxHealth) * barWidth);

        // Background
        g.setColor(Color.GRAY);
        g.fillRect(barX, barY, barWidth, barHeight);

        // Foreground (green)
        g.setColor(Color.GREEN);
        g.fillRect(barX, barY, healthBarWidth, barHeight);

        g.setColor(Color.BLACK);
        g.drawRect(barX,barY,barWidth,barHeight);

        // Health text on bar
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 14));
        g.drawString("Health: " + playerHealth + "/" + maxHealth, barX + 5, barY + 15);



        for(Enemy enemy:enemies){
            enemy.draw(g);
        }
        for(Tower tower:towers){
            tower.draw(g);
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (waveInProgress) {
            if (enemySpawnDelayTimer > enemySpawnDelay && enemiesLeftToSpawn > 0) {
                enemySpawnDelayTimer = 0;
                enemiesLeftToSpawn--;


                double r = Math.random();
                if (currentWave < 3) {
                    // Only basic enemies for early waves
                    enemies.add(new Enemy("basic", 5, 30, checkpoints[0][0], checkpoints[0][1], checkpoints));
                } else if (currentWave < 6) {
                    // Mix of basic and fast enemies
                    if (r < 0.7) {
                        enemies.add(new Enemy("basic", 5, 30, checkpoints[0][0], checkpoints[0][1], checkpoints));
                    } else {
                        enemies.add(new Enemy("fast", 10, 25, checkpoints[0][0], checkpoints[0][1], checkpoints));
                    }
                } else {
                    // Mix of all types
                    if (r < 0.5) {
                        enemies.add(new Enemy("basic", 5, 30, checkpoints[0][0], checkpoints[0][1], checkpoints));
                    } else if (r < 0.8) {
                        enemies.add(new Enemy("fast", 10, 25, checkpoints[0][0], checkpoints[0][1], checkpoints));
                    } else {
                        enemies.add(new Enemy("elite", 3, 55, checkpoints[0][0], checkpoints[0][1], checkpoints));
                    }
                }


            } else {
                enemySpawnDelayTimer++;
            }
        }


        //update stuff here




        // Update enemies
        for (Enemy enemy : enemies) {
            enemy.update();
        }
        //remove dead enemies or enemies off screen
        ArrayList<Enemy> enemiesToRemove = new ArrayList<>();
        for (Enemy enemy : enemies) {
            if (enemy.getHealth() == 0) {
                enemiesToRemove.add(enemy);
                if (deathSound != null) {
                    if (deathSound.isRunning()) {
                        deathSound.stop(); // Stop if it's still playing
                    }
                    deathSound.setFramePosition(0); // Rewind to the beginning
                    deathSound.start();
                }
            } else if (enemy.getX() > getWidth()) {
                enemiesToRemove.add(enemy);
                playerHealth--; // lose health when enemy escapes
                if (playerHealth <= 0) {
                    JOptionPane.showMessageDialog(this, "Game Over!");
                    timer.stop();
                }
            }
        }
        enemies.removeAll(enemiesToRemove);        if (waveInProgress&&enemiesLeftToSpawn == 0&&enemies.isEmpty()) {
            waveInProgress = false;
            try {
                shop.earnMoney((int)Math.pow(currentWave,1.2)*25);
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        }
        // Update towers
        for (Tower tower: towers) {
            tower.update(enemies);
        }
        repaint();
    }






    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();




        if(selectedTowerToPlace != null){
            selectedTowerToPlace.setX(x);
            selectedTowerToPlace.setY(y);
            towers.add(selectedTowerToPlace);
            selectedTowerToPlace = null;
        }


        repaint();
    }
    public void setShop(Shop shop){
        this.shop=shop;
    }




    @Override
    public void mousePressed(MouseEvent e) {




    }




    @Override
    public void mouseReleased(MouseEvent e) {




    }




    @Override
    public void mouseEntered(MouseEvent e) {




    }




    @Override
    public void mouseExited(MouseEvent e) {




    }
}









