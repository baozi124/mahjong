import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;


public class Game extends JPanel implements ActionListener, MouseListener {
    Timer timer;
    ArrayList<Enemy>enemies =  new ArrayList<>();
    ArrayList<Tower>towers = new ArrayList<>();
    long spawnTimer;
    int[][] checkpoints={{-50,400},{100,400},{100,100},{700,100},{700,250},{300,250},{300,450},{900,450}};
    public Game(){
        addMouseListener(this);
        spawnTimer=0;
        this.setFocusable(true);
        timer = new Timer(32, this);
        timer.start();


        towers.add(new Tower(500,150));
    }
    private Tower selectedTowerToPlace = null;
    public void setSelectedTowerToPlace(Tower tower){
        this.selectedTowerToPlace = tower;
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(new Color(137, 161, 122)); //background
        g.fillRect(0, 0, getWidth(), getHeight());


        // Draw path lines
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setColor(new Color(195, 175, 144));
        g2d.setStroke(new BasicStroke(75));


        for (int i = 0; i < checkpoints.length - 1; i++) {
            int x1 = checkpoints[i][0];
            int y1 = checkpoints[i][1];
            int x2 = checkpoints[i + 1][0];
            int y2 = checkpoints[i + 1][1];
            g2d.drawLine(x1, y1, x2, y2);
        }
        g2d.dispose();


        for(Enemy enemy:enemies){
            enemy.draw(g);
        }
        for(Tower tower:towers){
            tower.draw(g);
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        //increment spawn timer
        spawnTimer++;
        if(spawnTimer>30){//add new enemy every certain frames
            spawnTimer=0;
            if(Math.random()>.3){
                enemies.add(new Enemy("basic", 5, 20, checkpoints[0][0],checkpoints[0][1],checkpoints));
            }else if(Math.random()>.5){
                enemies.add(new Enemy("fast", 10, 15, checkpoints[0][0],checkpoints[0][1],checkpoints));
            }else{
                enemies.add(new Enemy("elite", 3, 35, checkpoints[0][0],checkpoints[0][1],checkpoints));
            }
        }
        //update stuff here


        // Update enemies
        for (Enemy enemy : enemies) {
            enemy.update();
        }
        //remove dead enemies or enemies off screen
        enemies.removeIf(enemy -> enemy.getX() > getWidth() || enemy.getHealth()==0);
        // Update towers
        for (Tower tower: towers) {
            tower.update(enemies);
        }
        repaint();
    }


    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();


        if(selectedTowerToPlace != null){
            selectedTowerToPlace.setX(x);
            selectedTowerToPlace.setY(y);
            towers.add(selectedTowerToPlace);
            selectedTowerToPlace = null;
        }

        repaint();
    }


    @Override
    public void mousePressed(MouseEvent e) {


    }


    @Override
    public void mouseReleased(MouseEvent e) {


    }


    @Override
    public void mouseEntered(MouseEvent e) {


    }


    @Override
    public void mouseExited(MouseEvent e) {


    }
}



