import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Game extends JPanel implements ActionListener {
    Timer timer;
    ArrayList<Enemy>enemies =  new ArrayList<>();
    ArrayList<Tower>towers = new ArrayList<>();
    long spawnTimer;
    public Game(){
        spawnTimer=0;
        this.setFocusable(true);
        timer = new Timer(32, this);
        timer.start();

        towers.add(new Tower(500,150));
        towers.add(new Tower(400,150));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(new Color(230, 230, 230)); // Sky blue
        g.fillRect(0, 0, getWidth(), getHeight());

        for(Enemy enemy:enemies){
            enemy.draw(g);
        }
        for(Tower tower:towers){
            tower.draw(g);
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        //increment spawn timer
        spawnTimer++;
        if(spawnTimer>30){//add new enemy every certain frames
            spawnTimer=0;
            System.out.println("spawn");
            enemies.add(new Enemy());
        }
        //update stuff here

        // Update enemies
        for (Enemy enemy : enemies) {
            enemy.update();
        }
        //remove dead enemies or enemies off screen
        enemies.removeIf(enemy -> enemy.getX() > getWidth() || enemy.getHealth()==0);
        // Update towers
        for (Tower tower: towers) {
            tower.update(enemies);
        }
        repaint();
    }
}
