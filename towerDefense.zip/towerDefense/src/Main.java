import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Tower Defense");
        Game gamePanel = new Game();
        gamePanel.setSize(800,600);
        Shop shopPanel = new Shop(gamePanel);
        shopPanel.setSize(200,600);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.add(gamePanel);
        frame.add(shopPanel);
        frame.setVisible(true);
        frame.setResizable(false);
    }
}