import javax.swing.*;
import java.awt.*;


public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Tower Defense");


        Game gamePanel = new Game();
        Shop shopPanel = new Shop(gamePanel);


        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);


        frame.add(gamePanel, BorderLayout.CENTER);
        frame.add(shopPanel, BorderLayout.EAST);


        frame.setVisible(true);
        frame.setResizable(false);
    }
}



