import java.awt.*;
import java.util.ArrayList;
import java.awt.*;
import java.awt.geom.AffineTransform;
import javax.swing.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.*;
import java.util.ArrayList;
public class Tower {

    // Fields
    private String name;
    private String suit;
    private boolean bought;
    private int x;
    private int y;
    private int damage;
    private long attackCooldown;
    private long lastAttack;
    private int size; // You can later adapt this to a custom Size class or enum if needed

    // Constructor
    public Tower(String name, String suit, boolean bought, int x, int y, int damage,
                 long attackCooldown, long lastAttack, int size) {
        this.name = name;
        this.suit = suit;
        this.bought = bought;
        this.x = x;
        this.y = y;
        this.damage = damage;
        this.attackCooldown = attackCooldown;
        this.lastAttack = lastAttack;
        this.size = size;
    }

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSuit() { return suit; }
    public void setSuit(String suit) { this.suit = suit; }

    public boolean isBought() { return bought; }
    public void setBought(boolean bought) { this.bought = bought; }

    public int getX() { return x; }
    public void setX(int x) { this.x = x; }

    public int getY() { return y; }
    public void setY(int y) { this.y = y; }

    public int getDamage() { return damage; }
    public void setDamage(int damage) { this.damage = damage; }

    public long getAttackCooldown() { return attackCooldown; }
    public void setAttackCooldown(long attackCooldown) { this.attackCooldown = attackCooldown; }

    public long getLastAttack() { return lastAttack; }
    public void setLastAttack(long lastAttack) { this.lastAttack = lastAttack; }

    public int getSize() { return size; }
    public void setSize(int size) { this.size = size; }

    // Optional: Behavior method (example)
    public boolean canAttack(long currentTime) {
        return (currentTime - lastAttack) >= attackCooldown;
    }

    public void attack(long currentTime, ArrayList<Enemy> enemies) {
        if (canAttack(currentTime)) {
            //search for closest enemy in range

            lastAttack = currentTime;
            // Attack logic goes here
        }
    }
    public void update(){
        //attack
    }
    public void draw(Graphics g){
        Graphics2D g2d=(Graphics2D)g;
    }
}

