import java.awt.*;
import java.util.ArrayList;
import java.awt.*;
import java.awt.geom.AffineTransform;
import javax.swing.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.*;
import java.util.ArrayList;
public class Tower {

    // Fields
    private String name;
    private String suit;
    private boolean bought;
    private int x;
    private int y;
    private int damage;
    private long attackCooldown;
    private long lastAttack;
    private int range;
    private int size; // You can later adapt this to a custom Size class or enum if needed

    Image sprite;
    // Constructor
    public Tower(int x, int y) {
        this.name = "basic";
        this.x = x;
        this.y = y;
        this.damage = 5;
        this.attackCooldown = 10;//in frames
        this.lastAttack = attackCooldown;
        this.range=100;
        try {
            sprite= ImageIO.read(new File("src/tower.png")).getScaledInstance(50,50,Image.SCALE_SMOOTH);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Tower(String name, int damage, int attackCooldown, int range, int x, int y) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.damage = damage;
        this.attackCooldown = attackCooldown;//in frames
        this.lastAttack = attackCooldown;
        this.range=range;
        try {
            sprite= ImageIO.read(new File("src/"+name+".png")).getScaledInstance(50,50,Image.SCALE_SMOOTH);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSuit() { return suit; }
    public void setSuit(String suit) { this.suit = suit; }

    public boolean isBought() { return bought; }
    public void setBought(boolean bought) { this.bought = bought; }

    public int getX() { return x; }
    public void setX(int x) { this.x = x; }

    public int getY() { return y; }
    public void setY(int y) { this.y = y; }

    public int getDamage() { return damage; }
    public void setDamage(int damage) { this.damage = damage; }

    public long getAttackCooldown() { return attackCooldown; }
    public void setAttackCooldown(long attackCooldown) { this.attackCooldown = attackCooldown; }

    public long getLastAttack() { return lastAttack; }
    public void setLastAttack(long lastAttack) { this.lastAttack = lastAttack; }

    public int getSize() { return size; }
    public void setSize(int size) { this.size = size; }

    public void attack(ArrayList<Enemy> enemies) {
        boolean enemyInRange=false;
        int minDistance=range;
        Enemy closestEnemy=new Enemy(new int[][]{{}});
        for (Enemy enemy:enemies){
            int dx = enemy.getX() - x;
            int dy = enemy.getY() - y;
            int dist = (int) Math.sqrt(dx * dx + dy * dy);
            if(dist<minDistance){
                closestEnemy=enemy;
                minDistance=range;
                enemyInRange=true;
            }
        }
        if(enemyInRange){
            closestEnemy.takeDamage(damage);//deal damage
            lastAttack=0;
        }
    }
    public void update(ArrayList<Enemy>enemies){
        lastAttack++;
        if(lastAttack>attackCooldown){//attack every cooldown interval
            attack(enemies);
        }
    }
    public void draw(Graphics g){
        Graphics2D g2d=(Graphics2D)g;

        int drawX=x-sprite.getWidth(null)/2;
        int drawY=y-sprite.getHeight(null)/2;
        // attack range circle
        int diameter = range * 2;
        if(lastAttack==0){
            g2d.setColor(new Color(255, 213, 0, 50));
        }else {
            g2d.setColor(new Color(255, 213, 0, 20));
        }
        g2d.fillOval(x - range, y - range, diameter, diameter);

        // Draw enemy sprite
        g2d.drawImage(sprite, drawX, drawY, null);
    }
}

