import javax.swing.*;
import java.awt.*;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javax.sound.sampled.*;


public class Main {
    public static void main(String[] args) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
        JFrame frame = new JFrame("Tower Defense");


        Game gamePanel = new Game();
        Shop shopPanel = new Shop(gamePanel);
        gamePanel.setShop(shopPanel);


        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);


        frame.add(gamePanel, BorderLayout.CENTER);
        frame.add(shopPanel, BorderLayout.EAST);


        frame.setVisible(true);
        frame.setResizable(false);


        while(true) {
            Scanner scanner = new Scanner(System.in);

            File file = new File("C:\\Users\\Alan\\IdeaProjects\\CompSci Group Project\\src\\Music\\clashOfClans.wav");
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);

            clip.loop(Clip.LOOP_CONTINUOUSLY);
            clip.start();

            String response = scanner.next();
        }
    }
}

