import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

public class Enemy {

    private int x;
    private int y;
    private int health;
    private int maxHealth;
    private int speed;
    private String name;
    private Image sprite;

    int[][] checkpoints;
    int checkpointNumber;
    public Enemy(int[][] checkpoints){
        x=-50;
        y=200;
        speed=5;
        maxHealth=15;
        health=maxHealth;
        name="basic";
        this.checkpoints=checkpoints;
        checkpointNumber=0;
        try {
            sprite= ImageIO.read(new File("src/Images/"+name+"Enemy.png")).getScaledInstance(50,50,Image.SCALE_SMOOTH);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public Enemy(int x, int y, int[][] checkpoints){
        this.x=x;
        this.y=y;
        speed=5;
        maxHealth=15;
        health=maxHealth;
        name="basic";
        this.checkpoints=checkpoints;
        checkpointNumber=0;
        try {
            sprite= ImageIO.read(new File("src/Images/"+name+"Enemy.png")).getScaledInstance(50,50,Image.SCALE_SMOOTH);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public Enemy(String name, int speed, int maxHealth, int x, int y, int[][] checkpoints){
        this.x=x;
        this.y=y;
        this.speed=speed;
        this.maxHealth=maxHealth;
        health=maxHealth;
        this.name=name;
        this.checkpoints=checkpoints;
        checkpointNumber=0;
        try {
            sprite= ImageIO.read(new File("src/Images/"+name+"Enemy.png")).getScaledInstance(50,50,Image.SCALE_SMOOTH);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void update() {
        if (checkpointNumber >= checkpoints.length) {
            x=x+speed; // No more checkpoints
        }

        int targetX = checkpoints[checkpointNumber][0];
        int targetY = checkpoints[checkpointNumber][1];

        int dx = targetX - x;
        int dy = targetY - y;

        double distance = Math.sqrt(dx * dx + dy * dy);

        // If close to the checkpoint, move to next
        if (distance < speed) {
            x = targetX;
            y = targetY;
            checkpointNumber++;
        } else {
            // Move toward checkpoint
            double directionX = dx / distance;
            double directionY = dy / distance;

            x += (int)(directionX * speed);
            y += (int)(directionY * speed);
        }
    }

    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        int drawX=x-sprite.getWidth(null)/2;
        int drawY=y-sprite.getHeight(null)/2;
        // Draw enemy sprite
        g2d.drawImage(sprite, drawX, drawY, null);

        // === Draw health bar ===
        if(health<maxHealth){
            int barWidth = 50;
            int barHeight = 6;
            int barX = drawX;
            int barY = drawY - 10; // 10 pixels above the enemy

            // Health ratio (remaining HP as a percent)
            float healthRatio = (float) health / maxHealth;

            // Background (red bar)
            g2d.setColor(Color.GRAY);
            g2d.fillRect(barX, barY, barWidth, barHeight);

            // Foreground (green part)
            g2d.setColor(Color.GREEN);
            g2d.fillRect(barX, barY, (int)(barWidth * healthRatio), barHeight);

            // Optional: border
            g2d.setColor(Color.BLACK);
            g2d.drawRect(barX, barY, barWidth, barHeight);
        }
    }

    public void takeDamage(int damage){
        health=health-damage;
        if(health<0){
            health=0;
        }
    }
}
